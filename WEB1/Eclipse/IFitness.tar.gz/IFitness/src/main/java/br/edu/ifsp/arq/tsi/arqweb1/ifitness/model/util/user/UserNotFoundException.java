package br.edu.ifsp.arq.tsi.arqweb1.ifitness.model.util.user;

public class UserNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public UserNotFoundException(String message) {
		super(message);
	}

}

