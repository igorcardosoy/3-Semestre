package br.edu.ifsp.arq.tsi.arqweb1.ifitness.model.util.activity;

public class ActivityTypeNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ActivityTypeNotFoundException(String message) {
		super(message);
	}
}
